﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

    public Transform target;
    public float controlSpeed;
    public float menuSpeed;
    public AnimationCurve menuScrollCurve;
    public float verticalOffset;
    public int cameraState = 1;

    MainMenuController menuController;
    float scrollPercent = 0;
    float previousAngle;

    void Start()
    {
        menuController = FindObjectOfType<MainMenuController>();
        menuController.OnGameStart += GameStart;
    }

    void Update()
    {
        
    }

    void LateUpdate()
    {
        if(cameraState == 0)
        {
            transform.RotateAround(Vector3.zero, Vector3.up, Input.GetAxisRaw("Horizontal") * controlSpeed * Time.deltaTime);
        } else if(cameraState == 1)
        {
            transform.RotateAround(Vector3.zero, Vector3.up, menuSpeed * Time.deltaTime);
        } else if(cameraState == 2)
        {
            if(scrollPercent <= 1)
            {
                transform.rotation = Quaternion.Euler(new Vector3(8, previousAngle + Mathf.LerpAngle(0, 30, menuScrollCurve.Evaluate(scrollPercent))));
                scrollPercent += 0.01f;
            } else
            {
                cameraState = 0;
            }
        }
    }

    void GameStart()
    {
        scrollPercent = 0;
        cameraState = 2;
        previousAngle = transform.rotation.eulerAngles.y;
    }
}
