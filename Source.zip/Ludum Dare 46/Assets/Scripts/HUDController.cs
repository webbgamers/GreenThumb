﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HUDController : MonoBehaviour
{
    public GameObject HUD;
    
    MainMenuController menuController;

    void Start()
    {
        menuController = FindObjectOfType<MainMenuController>();
        menuController.OnGameStart += GameStart;
    }

    void GameStart()
    {
        HUD.SetActive(true);
    }
}
