﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Plant : MonoBehaviour
{
    // public variables
    public float waterDecreaseRate = 0.07f;
    public float nutrientDecreaseRate = 0.04f;
    public float paintDecreaseRate = 0.01f;
    public float regenRate = 0.02f;
    public Text score;
    public GameObject gameOver;
    public GameObject fire;
    public GameObject dirt;
    public Color dirtWetColor;
    public Color dirtDryColor;
    public GameObject stem;
    public Color stemHealthyColor;
    public Color stemDeadColor;
    public GameObject leaf1;
    public GameObject leaf2;
    public GameObject leaf3;
    public Color infectedLeafColor;
    public Color healthyLeafColor;
    public GameObject flower;
    public Color paintedFlowerColor;
    public Color dullFlowerColor;
    public GameObject healthBar;
    public GameObject waterBar;
    public GameObject nutrientBar;
    public GameObject paintBar;
    public GameObject virusBar;

    // event data
    float[] eventChances = {0.0001f, 0.00075f};
    string[] eventNames = {"fire", "virus"};

    // local variables
    float nextUpdateTime = 0;
    float waterLevel = 1;
    float nutrientLevel = 1;
    float paintLevel = 1;
    float virusLevel = 0;
    float health = 1;
    List<string> currentEvents = new List<string>();
    MainMenuController menuController;
    public bool gameStarted = false;
    List<GameObject> leaves = new List<GameObject>();
    float reloadTime = Mathf.Infinity;
    bool gameOverDisplayed = false;

    void Start()
    {
        dirt = GameObject.Find("Dirt");
        menuController = FindObjectOfType<MainMenuController>();
        menuController.OnGameStart += GameStart;
        leaves.Add(leaf1);
        leaves.Add(leaf2);
        leaves.Add(leaf3);
    }

    void Update()
    {
        if(gameStarted)
        {
            if(nextUpdateTime < Time.time)
            {
                UpdateWaterLevel();
                UpdateNutrientLevel();
                UpdatePaintLevel();
                UpdateHealth();

                if(virusLevel == 1)
                {
                    health -= 0.1f;
                }

                print("updated values");

                UpdateValueIndicators();

                nextUpdateTime = Time.time + 1f;
            }

            if(health <= 0)
            {
                print("game over");
                gameOver.SetActive(true);
                if(!gameOverDisplayed)
                {
                    score.text = Time.time.ToString();
                    gameOverDisplayed = true;
                    reloadTime = Time.time + 5f;
                }
            }

            if(reloadTime < Time.time)
            {
                SceneManager.LoadScene(0);
            }

            // event starter
            {
                float randomValue = Random.Range(0f, 1f);
                int i = 0;
                foreach(float targetValue in eventChances)
                {
                    if(targetValue > randomValue)
                    {
                        currentEvents.Add(eventNames[i]);
                        break;
                    }
                    i++;
                }
            }

            ExecuteEvent();
        }
    }
        
    void UpdateWaterLevel() 
    {
        float waterLevelRaw = waterLevel - (waterDecreaseRate * Difficulty.GetDifficultyMultiplier());
        print(waterLevelRaw);
        if(waterLevelRaw <= 0)
        {
            health += waterLevelRaw;
        }
        waterLevel = Mathf.Clamp01(waterLevelRaw);
    }

    void UpdateNutrientLevel()
    {
        float nutrientLevelRaw = nutrientLevel - (nutrientDecreaseRate * Difficulty.GetDifficultyMultiplier());
        print(nutrientLevelRaw);
        if(nutrientLevelRaw <= 0)
        {
            health += nutrientLevelRaw;
        }
        nutrientLevel = Mathf.Clamp01(nutrientLevelRaw);
    }

    void UpdatePaintLevel()
    {
        float paintLevelRaw = paintLevel - (paintDecreaseRate * Difficulty.GetDifficultyMultiplier());
        if(paintLevelRaw <= 0)
        {
            health += paintLevelRaw;
        }
        paintLevel = Mathf.Clamp01(paintLevelRaw);
    }

    void UpdateHealth()
    {
        if(health < 1)
        {
            if((waterLevel > 0) && (nutrientLevel > 0) && (paintLevel > 0) && (virusLevel <= 0))
            {
                health += regenRate;
                waterLevel -= regenRate;
                nutrientLevel -= regenRate;
            }
        }
    }

    void UpdateValueIndicators()
    {
        dirt.GetComponent<Renderer>().material.color = Color.Lerp(dirtDryColor, dirtWetColor, waterLevel);
        stem.GetComponent<Renderer>().material.color = Color.Lerp(stemDeadColor, stemHealthyColor, health);
        flower.GetComponent<Renderer>().material.color = Color.Lerp(dullFlowerColor, paintedFlowerColor, paintLevel);
        leaf1.GetComponent<Renderer>().material.color = Color.Lerp(healthyLeafColor, infectedLeafColor, virusLevel);
        leaf2.GetComponent<Renderer>().material.color = Color.Lerp(healthyLeafColor, infectedLeafColor, virusLevel);
        leaf3.GetComponent<Renderer>().material.color = Color.Lerp(healthyLeafColor, infectedLeafColor, virusLevel);
        healthBar.GetComponent<ValueBar>().SetValue(health);
        waterBar.GetComponent<ValueBar>().SetValue(waterLevel);
        nutrientBar.GetComponent<ValueBar>().SetValue(nutrientLevel);
        paintBar.GetComponent<ValueBar>().SetValue(paintLevel);
        virusBar.GetComponent<ValueBar>().SetValue(virusLevel);
    }

    public void ApplyEffect(Effect effect)
    {
        float waterLevelRaw = waterLevel + effect.water;
        ApplyOverflow(waterLevelRaw);
        waterLevel = Mathf.Clamp01(waterLevelRaw);

        float nutrientLevelRaw = nutrientLevel + effect.nutrients;
        ApplyOverflow(nutrientLevelRaw);
        nutrientLevel = Mathf.Clamp01(nutrientLevelRaw);

        float paintLevelRaw = paintLevel + effect.paint;
        ApplyOverflow(paintLevelRaw);
        paintLevel = Mathf.Clamp01(paintLevelRaw);

        float virusLevelRaw = virusLevel - effect.antiVirus;
        if(virusLevelRaw < 0)
        {
            health += virusLevelRaw;
        }
        virusLevel = Mathf.Clamp01(virusLevelRaw);

        UpdateValueIndicators();
    }

    void ExecuteEvent()
    {
        if (currentEvents.Count > 0)
        {
            for(int i = 0; i < currentEvents.Count; i++)
            {
                switch(currentEvents[i])
                {
                    case "fire":
                        fire.SetActive(true);
                        waterLevel = Mathf.Clamp01(waterLevel -= 0.001f);
                        float randomNumber = Random.Range(0f, 1f);
                        if(randomNumber < 0.0005)
                        {
                            currentEvents.Remove("fire");
                            fire.SetActive(false);
                        }
                        break;
                    case "virus":
                        virusLevel = Mathf.Clamp01(virusLevel + Random.Range(0.3f, 0.6f));
                        currentEvents.Remove("virus");
                        break;
                }
            }
        }
    }

    void ApplyOverflow(float value)
    {
        if(value > 1)
        {
            health -= value - 1;
        }
    }

    void GameStart()
    {
        gameStarted = true;
    }
}
