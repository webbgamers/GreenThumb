﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectable : MonoBehaviour
{
    public float waterEffect;
    public float nutrientEffect;
    public float paintEffect;
    public float antiVirusEffect;
    public string itemName;
    public string targetTag;
    public Texture2D itemCursor;
    public Item item;

    void Awake()
    {
        item = new Item(itemName, itemCursor, targetTag, new Effect(waterEffect, nutrientEffect, paintEffect, antiVirusEffect));
    }
    
}
