﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect
{
    public float water;
    public float nutrients;
    public float paint;
    public float antiVirus;

    public Effect(float waterEffect, float nutrientEffect, float paintEffect, float antiVirusEffect)
    {
        this.water = waterEffect;
        this.nutrients = nutrientEffect;
        this.paint = paintEffect;
        this.antiVirus = antiVirusEffect;
    }
}
