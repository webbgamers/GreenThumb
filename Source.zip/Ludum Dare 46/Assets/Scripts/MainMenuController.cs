﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;

public class MainMenuController : MonoBehaviour
{
    public event Action OnGameStart;
    public GameObject mainMenu;
    public Button startButton;

    void Start()
    {
	    startButton.onClick.AddListener(TaskOnClick);
    }

    void Update()
    {
        
    }

    void TaskOnClick()
    {
        OnGameStart();
        mainMenu.SetActive(false);
    }
}
