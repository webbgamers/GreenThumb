﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Difficulty
{
    static float difficultyScale = 0.01f;
    static float difficultyCap = 10;

    public static float GetDifficultyMultiplier()
    {
        float difficultyMultiplier = Mathf.Clamp(Time.timeSinceLevelLoad * difficultyScale, 1f, difficultyCap);
        return difficultyMultiplier;
    }

}
