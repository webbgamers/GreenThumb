﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Texture2D idleCursor;
    public GameObject plantManager;

    MainMenuController menuController;
    bool gameStarted = true;
    Item heldItem;
    Vector2 cursorCenter = new Vector2(12,12);

    void Start()
    {
        menuController = FindObjectOfType<MainMenuController>();
        menuController.OnGameStart += GameStart;
        Cursor.SetCursor(idleCursor, cursorCenter, CursorMode.Auto);
    }

    void Update()
    {
        if(gameStarted)
        {
            if(Input.GetMouseButtonUp(0))
            {   
                GameObject selectedObject = GetMousedObject();
                if(selectedObject != null)
                {
                    if(selectedObject.GetComponent<Collectable>() != null)
                    {
                        Item selectedItem = selectedObject.GetComponent<Collectable>().item;
                        Cursor.SetCursor(selectedItem.cursor, cursorCenter, CursorMode.Auto);
                        heldItem = selectedItem;
                    }
                    else if(selectedObject.transform.parent != null)
                    {
                        if(heldItem != null)
                        {
                            if(selectedObject.transform.parent == plantManager.transform)
                            {
                                if(selectedObject.tag == heldItem.targetTag)
                                {
                                    plantManager.GetComponent<Plant>().ApplyEffect(heldItem.effect);
                                    print("Applied " + heldItem.name);
                                    Cursor.SetCursor(idleCursor, cursorCenter, CursorMode.Auto);
                                    heldItem = null;
                                }
                            }
                        }
                    }
                } 
                else
                {
                    Cursor.SetCursor(idleCursor, cursorCenter, CursorMode.Auto);
                    heldItem = null;
                }
            }
        }
    }

    void GameStart()
    {
        gameStarted = true;
    }

    GameObject GetMousedObject()
    {
        GameObject mousedObject = null;
        RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out hit))
            {
                Debug.DrawLine(Camera.main.transform.position, hit.point, Color.red);
                if (hit.transform != null) 
                {
                    mousedObject = hit.collider.transform.gameObject;
                }
            }
        return mousedObject;
    }
}

