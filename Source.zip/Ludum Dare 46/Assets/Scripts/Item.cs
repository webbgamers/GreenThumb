﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item
{
    public string name;
    public Texture2D cursor;
    public string targetTag;
    public Effect effect;

    public Item(string itemName, Texture2D itemCursor, string targetTag, Effect effects)
    {
        this.name = itemName;
        this.cursor = itemCursor;
        this.targetTag = targetTag;
        this.effect = effects;
    }
}
